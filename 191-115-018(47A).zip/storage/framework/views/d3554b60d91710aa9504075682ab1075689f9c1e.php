<h1 style="text-align:center;">Products List</h1>

<table border ="1">

<tr>
    
    <th>Category</th>
    <th>Image</th>
    <th>Operation</th>
    

</tr>
<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
      
   
    <th><?php echo e($Product['sel']); ?></th>
    <th><img src=<?php echo e($Product['pic']); ?> style="height : 100px;" alt=""></th>
    <th><a href=<?php echo e("delete/".$Product['pic']); ?>>Delete</a></th>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table><?php /**PATH C:\Users\RIFAT RAHMAN\Desktop\bike\blog\resources\views/dlist.blade.php ENDPATH**/ ?>